// script.js
document.querySelectorAll('.filters button').forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;
    document.querySelectorAll('.photo').forEach(photo => {
      if (filter === 'all' || photo.classList.contains(filter)) {
        photo.style.display = 'block';
      } else {
        photo.style.display = 'none';
      }
    });
  });
});
const lightbox = document.getElementById('lightbox');
const lightboxImg = lightbox.querySelector('img');
const closeBtn = lightbox.querySelector('.close');
document.querySelectorAll('.photo img').forEach(img => {
  img.addEventListener('click', () => {
    lightboxImg.src = img.src;
    lightbox.classList.remove('hidden');
  });
});
closeBtn.addEventListener('click', () => {
  lightbox.classList.add('hidden');
});
